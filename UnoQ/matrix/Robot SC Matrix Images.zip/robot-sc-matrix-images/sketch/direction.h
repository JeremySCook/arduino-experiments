// Animation: Animation

// direction.h
const uint32_t directionB[4] = {
    0x0c00c00c,
    0x00ffe7ff,
    0x18006001,
    0x80000000
};

const uint32_t directionF[4] = {
    0x01800600,
    0x181fe0ff,
    0x00300300,
    0x30000000
};

const uint32_t directionL[4] = {
    0x06007807,
    0xe06d8264,
    0x03001800,
    0xc0000000
};

const uint32_t directionR[4] = {
    0x06003001,
    0x804c836c,
    0x0fc03c00,
    0xc0000000
};

const uint32_t directionS[4] = {
    0x00007807,
    0xe0330198,
    0x0fc03c00,
    0x00000000
};