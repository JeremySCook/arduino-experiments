# 😀 matrix-text-noscroll

Example displaying static text