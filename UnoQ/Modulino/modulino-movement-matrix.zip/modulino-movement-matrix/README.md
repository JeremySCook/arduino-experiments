# 😀 modulino movement sensor

Displays results of one Y axis, nominally pointing straight down (-1) or straight up (+1)  
as configured on the roller on built-in LED matrix.

This and other acceleration and angular statistics printed on serial monitor.

![image](images/MovementPinouts.png)


