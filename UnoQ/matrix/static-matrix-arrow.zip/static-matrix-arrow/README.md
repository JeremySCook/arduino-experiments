# 😀 Static-Matrix-Arrow - shows a static arrow on the LED matrix




