Robot SC Sensors AUTO

Derived from Robot Sero Chassis Matrix Images  
Features autonomous wandering & startup calibration for pitch/roll

Web-interface dual-servo differential steering robot with matrix  
images that display to show movements

Uses Python code to generate web interface, sending signals to  
microcontroller via the bridge function.

Run, copy address from Python output (including http) and paste into  
web browser to generate control interface.