#include <ArduinoGraphics.h>
#include <Arduino_LED_Matrix.h>

ArduinoLEDMatrix matrix; // create object named matrix

void setup() {
  matrix.begin(); // onboard 13x8 matrix
  matrix.textFont(Font_4x6); // use 4x6 font
  matrix.clear();
}

void loop() {
  matrix.beginText(1, 1, 0xFFFFFF); // start 1 px down, 1 px right from top-left
  matrix.print("HEY");
  matrix.endText(NO_SCROLL); // static text, no scrolling
}