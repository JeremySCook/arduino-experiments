#include <ArduinoGraphics.h>
#include <Arduino_LED_Matrix.h>

ArduinoLEDMatrix matrix; // create object named matrix

void setup() {
  matrix.begin(); // onboard 13x8 matrix
  matrix.textFont(Font_5x7); // use 5x7 font
  matrix.textScrollSpeed(100);
}

void loop() {
  matrix.beginText(0, 1, 0xFFFFFF); // start 1 px down, 0 px right from top-left
  matrix.print("HELLO ROBOT");
  matrix.endText(SCROLL_LEFT);
}