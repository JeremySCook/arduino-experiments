from arduino.app_utils import *
from arduino.app_bricks.web_ui import WebUI


def forward_handler(client, data):
    print("FORWARD")
    Bridge.call("forward")


def backward_handler(client, data):
    print("BACKWARD")
    Bridge.call("backward")


def left_handler(client, data):
    print("LEFT")
    Bridge.call("left")


def right_handler(client, data):
    print("RIGHT")
    Bridge.call("right")


def stop_handler(client, data):
    print("STOP")
    Bridge.call("stop")


ui = WebUI()

ui.on_message('forward', forward_handler)
ui.on_message('backward', backward_handler)
ui.on_message('left', left_handler)
ui.on_message('right', right_handler)
ui.on_message('stop', stop_handler)

App.run()