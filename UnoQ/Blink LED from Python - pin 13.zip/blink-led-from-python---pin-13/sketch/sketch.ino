// SPDX-FileCopyrightText: Copyright (C) Arduino s.r.l. and/or its affiliated companies
//
// SPDX-License-Identifier: MPL-2.0

#include "Arduino_RouterBridge.h"

void setup() {
    pinMode(13, OUTPUT);

    Bridge.begin();
    Bridge.provide("set_led_state", set_led_state_MCU); // Bridge name: "set_led_state" - MCU function: set_led_state_MCU
}

void loop() {
}

void set_led_state_MCU(bool state) {
    // HIGH state means LED is ON (opposite of builtin LED behavior)
    digitalWrite(13, state ? LOW : HIGH); // If state is true do the first option (LOW), if false, second option (HIGH)
}