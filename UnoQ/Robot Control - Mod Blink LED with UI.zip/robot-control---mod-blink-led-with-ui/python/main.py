from arduino.app_utils import *
from arduino.app_bricks.web_ui import WebUI


def forward_handler(client, data):
    print("FORWARD")


def backward_handler(client, data):
    print("BACKWARD")


def left_handler(client, data):
    print("LEFT")


def right_handler(client, data):
    print("RIGHT")


def stop_handler(client, data):
    print("STOP")


# Initialize WebUI
ui = WebUI()

# Handle messages from the web interface
ui.on_message('forward', forward_handler)
ui.on_message('backward', backward_handler)
ui.on_message('left', left_handler)
ui.on_message('right', right_handler)
ui.on_message('stop', stop_handler)

# Start the application
App.run()