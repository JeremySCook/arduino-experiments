// Animation: Animation

// direction.h
const uint32_t directionStop[4] = {
    0x0c00c00c,
    0x00ff07f8,
    0x18006001,
    0x80000000
};