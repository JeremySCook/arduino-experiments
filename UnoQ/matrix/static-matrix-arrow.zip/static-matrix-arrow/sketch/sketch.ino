#include "direction.h"
#include <Arduino_LED_Matrix.h>

ArduinoLEDMatrix matrix;

void setup() {
  matrix.begin();
  matrix.clear();
  matrix.loadFrame(directionStop);
}

  void loop() {}