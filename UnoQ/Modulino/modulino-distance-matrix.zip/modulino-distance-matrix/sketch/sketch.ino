#include <ArduinoGraphics.h>
#include <Arduino_LED_Matrix.h>
#include <Modulino.h>

ArduinoLEDMatrix matrix;

// Create object instance
ModulinoDistance distance;

void setup() {
  Serial.begin(9600);

  // Initialize the Modulino system and distance sensor
  Modulino.begin();
  distance.begin();
  matrix.begin();
  matrix.textFont(Font_4x6);
}

void showText(const char* text) {
    matrix.clear();
    matrix.beginText(1, 1, 0xFFFFFF);
    matrix.print(text);
    matrix.endText(NO_SCROLL);
}

void loop() {
  if (distance.available()) {
    int measure = distance.get();
    Serial.println(measure);
    
    char textBuffer[10];
    sprintf(textBuffer, "%d", measure);
    showText(textBuffer);
  }
  delay(50);
}