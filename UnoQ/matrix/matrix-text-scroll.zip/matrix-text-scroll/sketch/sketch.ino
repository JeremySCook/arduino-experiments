#include <ArduinoGraphics.h>
#include <Arduino_LED_Matrix.h>

ArduinoLEDMatrix matrix;

void setup() {
  matrix.begin();
  matrix.textFont(Font_5x7);
  matrix.textScrollSpeed(100);
}

void loop() {
  matrix.beginText(0, 1, 0xFFFFFF);
  matrix.print("HELLO ROBOT");
  matrix.endText(SCROLL_LEFT);
}