#include <ArduinoGraphics.h>
#include <Arduino_LED_Matrix.h>
#include <Servo.h>
#include <Arduino_RouterBridge.h>

ArduinoLEDMatrix matrix;

Servo servo1;
Servo servo2;

void forward() {
    Monitor.println("MCU: FORWARD");
    showText("FWD");
    servo1.write(0);
    servo2.write(180);
}

void backward() {
    Monitor.println("MCU: BACKWARD");
    showText("BKW");
    servo1.write(180);
    servo2.write(0);
}

void left() {
    Monitor.println("MCU: LEFT");
    showText("LT");
    servo1.write(0);
    servo2.write(0);
}

void right() {
    Monitor.println("MCU: RIGHT");
    showText("RT");
    servo1.write(180);
    servo2.write(180);
}

void stopServos() {
    Monitor.println("MCU: STOP");
    showText("STP");
    servo1.write(90);
    servo2.write(90);
}

void showText(const char* text) {
    matrix.clear();
    matrix.beginText(1, 1, 0xFFFFFF);
    matrix.print(text);
    matrix.endText(NO_SCROLL);
}

void setup() {

    matrix.begin();
    matrix.textFont(Font_4x6);
   
    servo1.attach(9);
    servo2.attach(10);

    Monitor.begin();
    Bridge.begin();

    Bridge.provide_safe("forward", forward);
    Bridge.provide_safe("backward", backward);
    Bridge.provide_safe("left", left);
    Bridge.provide_safe("right", right);
    Bridge.provide_safe("stop", stopServos);

    stopServos();

    Monitor.println("MCU: Bridge ready");
}

void loop() {
}