#include <Servo.h>
#include <Arduino_RouterBridge.h>

Servo servo1;
Servo servo2;

void forward() {
    Monitor.println("MCU: FORWARD");

    servo1.write(0);
    servo2.write(180);
}

void backward() {
    Monitor.println("MCU: BACKWARD");

    servo1.write(180);
    servo2.write(0);
}

void left() {
    Monitor.println("MCU: LEFT");

    servo1.write(0);
    servo2.write(0);
}

void right() {
    Monitor.println("MCU: RIGHT");

    servo1.write(180);
    servo2.write(180);
}

void stopServos() {
    Monitor.println("MCU: STOP");

    servo1.write(90);
    servo2.write(90);
}

void setup() {
    servo1.attach(9);
    servo2.attach(10);

    Monitor.begin();
    Bridge.begin();

    Bridge.provide_safe("forward", forward);
    Bridge.provide_safe("backward", backward);
    Bridge.provide_safe("left", left);
    Bridge.provide_safe("right", right);
    Bridge.provide_safe("stop", stopServos);

    stopServos();

    Monitor.println("MCU: Bridge ready");
}

void loop() {
}