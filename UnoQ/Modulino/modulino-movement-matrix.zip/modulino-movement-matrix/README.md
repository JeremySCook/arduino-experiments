# 😀 modulino movement sensor

Displays results of one axis on LED matrix




