#include <ArduinoGraphics.h>
#include <Arduino_LED_Matrix.h>
#include <Modulino.h>

ArduinoLEDMatrix matrix;
ModulinoMovement movement;

float x, y, z;
float roll, pitch, yaw;

void setup() {
  Serial.begin(9600);
  // Initialize Modulino I2C communication
  Modulino.begin();
  // Detect and connect to movement sensor module
  movement.begin();
  matrix.begin();
  matrix.textFont(Font_4x6);
}

void showText(const char* text) {
    matrix.clear();
    matrix.beginText(1, 1, 0xFFFFFF);
    matrix.print(text);
    matrix.endText(SCROLL_LEFT);
    matrix.textScrollSpeed(50);
}

void loop() {
  // Read new movement data from the sensor
  movement.update();

  // Get acceleration and gyroscope values
  x = movement.getX();
  y = movement.getY();
  z = movement.getZ();
  roll = movement.getRoll();
  pitch = movement.getPitch();
  yaw = movement.getYaw();

  // Print acceleration values
  Serial.print("A: ");
  Serial.print(x, 3);
  Serial.print(", ");
  Serial.print(y, 3);
  Serial.print(", ");
  Serial.print(z, 3);
  
  // Print divider between acceleration and gyroscope
  Serial.print(" | G: ");
  
  // Print gyroscope values
  Serial.print(roll, 1);
  Serial.print(", ");
  Serial.print(pitch, 1);
  Serial.print(", ");
  Serial.println(yaw, 1);

  char textBuffer[10];
  sprintf(textBuffer, "%.1f", y);
  showText(textBuffer);
  
  delay(200);
}