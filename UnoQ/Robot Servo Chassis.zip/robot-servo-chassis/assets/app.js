const forwardButton = document.querySelector('#forward-button');
const backwardButton = document.querySelector('#backward-button');
const leftButton = document.querySelector('#left-button');
const rightButton = document.querySelector('#right-button');
const stopButton = document.querySelector('#stop-button');

const statusText = document.querySelector('#status');

// How often to repeat the current direction command while held
const COMMAND_INTERVAL = 100;

// Initialize UI
const ui = new WebUI();

ui.on_connect(onUIConnected);
ui.on_disconnect(onUIDisconnected);


// Called when the WebSocket connection is established
function onUIConnected() {
    statusText.textContent = 'Connected';

    setupDirectionButton(forwardButton, 'forward');
    setupDirectionButton(backwardButton, 'backward');
    setupDirectionButton(leftButton, 'left');
    setupDirectionButton(rightButton, 'right');

    stopButton.addEventListener('click', sendStop);

    console.log('Connected to the server');
}


// Called when the WebSocket connection is lost
function onUIDisconnected() {
    statusText.textContent = 'Disconnected';

    console.log('Disconnected from the server');
}


// Set up a directional button for press/release operation
function setupDirectionButton(button, direction) {

    let commandTimer = null;
    let buttonIsDown = false;

    button.addEventListener('pointerdown', function(event) {
        event.preventDefault();

        // Ignore additional pointer-down events
        if (buttonIsDown) {
            return;
        }

        buttonIsDown = true;

        // Keep receiving pointer events for this button
        button.setPointerCapture(event.pointerId);

        // Send the command immediately
        ui.send_message(direction);
        console.log('Pressed: ' + direction);

        // Continue sending the command while the button is held
        commandTimer = setInterval(function() {
            ui.send_message(direction);
        }, COMMAND_INTERVAL);
    });


    button.addEventListener('pointerup', function(event) {
        event.preventDefault();

        if (!buttonIsDown) {
            return;
        }

        buttonIsDown = false;

        stopCommandTimer();
        sendStop();

        if (button.hasPointerCapture(event.pointerId)) {
            button.releasePointerCapture(event.pointerId);
        }
    });


    button.addEventListener('pointercancel', function(event) {
        event.preventDefault();

        if (!buttonIsDown) {
            return;
        }

        buttonIsDown = false;

        stopCommandTimer();
        sendStop();
    });


    button.addEventListener('lostpointercapture', function() {
        // Do not send another STOP here.
        // pointerup/pointercancel already handle the stop.
        stopCommandTimer();
    });


    function stopCommandTimer() {
        if (commandTimer !== null) {
            clearInterval(commandTimer);
            commandTimer = null;
        }
    }
}


// Send a stop command
function sendStop() {
    ui.send_message('stop');
    console.log('Sent: stop');
}