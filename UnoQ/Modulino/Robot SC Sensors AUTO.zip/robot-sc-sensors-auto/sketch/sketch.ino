#include <ArduinoGraphics.h>
#include <Arduino_LED_Matrix.h>
#include <Servo.h>
#include <Arduino_RouterBridge.h>
#include <Arduino_Modulino.h>
#include "direction.h"

ArduinoLEDMatrix matrix;
ModulinoMovement movement;
ModulinoDistance distance;
ModulinoBuzzer buzzer;

unsigned long lastMovementRead = 0;
float tiltPitch = 0;
float tiltRoll = 0;
float currentDistanceMm = 9999.0;

float pitchOffset = 0;
float rollOffset = 0;
bool calibrationFlashOn = false;

float pitchSum = 0;
float rollSum = 0;

int calibrationCount = 0;
const int calibrationSamples = 10;
bool calibrationComplete = false;

bool autonomousMode = false;

enum AutoState {
    AUTO_FORWARD,
    AUTO_REVERSE,
    AUTO_TURN
};

AutoState autoState = AUTO_FORWARD;
unsigned long autoStateStart = 0;

const float OBSTACLE_DISTANCE = 250.0;
const unsigned long REVERSE_TIME = 400;
const unsigned long TURN_TIME = 500;

Servo servo1;
Servo servo2;

void forward() {
    Monitor.println("MCU: FORWARD");
    matrix.clear();
    matrix.loadFrame(directionF);
    servo1.write(0);
    servo2.write(180);
}

void backward() {
    Monitor.println("MCU: BACKWARD");
    matrix.clear();
    matrix.loadFrame(directionB);
    servo1.write(180);
    servo2.write(0);
}

void left() {
    Monitor.println("MCU: LEFT");
    matrix.clear();
    matrix.loadFrame(directionL);
    servo1.write(0);
    servo2.write(0);
}

void right() {
    Monitor.println("MCU: RIGHT");
    matrix.clear();
    matrix.loadFrame(directionR);
    servo1.write(180);
    servo2.write(180);
}

void stopServos() {
    Monitor.println("MCU: STOP");
    matrix.clear();
    matrix.loadFrame(directionS);
    servo1.write(90);
    servo2.write(90);
}

void manualForward() {
    autonomousMode = false;
    forward();
}

void manualBackward() {
    autonomousMode = false;
    backward();
}

void manualLeft() {
    autonomousMode = false;
    left();
}

void manualRight() {
    autonomousMode = false;
    right();
}

void manualStop() {
    autonomousMode = false;
    stopServos();
}

void buzzerOn() {
    buzzer.tone(1000, 60000);
}

void buzzerOff() {
    buzzer.noTone();
}

void autonomousOn() {
    autonomousMode = true;
    autoState = AUTO_FORWARD;
    autoStateStart = millis();

    Monitor.println("MCU: AUTONOMOUS ON");
    forward();
}

void autonomousOff() {
    autonomousMode = false;

    Monitor.println("MCU: AUTONOMOUS OFF");
    stopServos();
}

void setup() {

    matrix.begin();
    Modulino.begin();
    movement.begin();
    //delay(500);
    //calibrateMovement();
    distance.begin();
    buzzer.begin();
   
    servo1.attach(9);
    servo2.attach(10);

    Monitor.begin();
    Bridge.begin();

    Bridge.provide_safe("forward", manualForward);
    Bridge.provide_safe("backward", manualBackward);
    Bridge.provide_safe("left", manualLeft);
    Bridge.provide_safe("right", manualRight);
    Bridge.provide_safe("stop", manualStop);

    Bridge.provide_safe("autonomous_on", autonomousOn);
    Bridge.provide_safe("autonomous_off", autonomousOff);
    Bridge.provide_safe("buzzer_on", buzzerOn);
    Bridge.provide_safe("buzzer_off", buzzerOff);

    stopServos();

    Monitor.println("MCU: Bridge ready");
}

void loop() {

if (millis() - lastMovementRead >= 200) {
  lastMovementRead = millis();

if (movement.update()) {
    float x = movement.getX();
    float y = movement.getY();
    float z = movement.getZ();

    float rawPitch = atan2(z, sqrt(x * x + y * y)) * 180.0 / PI;
    float rawRoll = atan2(x, -y) * 180.0 / PI;

if (!calibrationComplete) {
    pitchSum += rawPitch;
    rollSum += rawRoll;
    calibrationCount++;

    calibrationFlashOn = !calibrationFlashOn;

    if (calibrationFlashOn) {
        matrix.loadFrame(directionS);
    } else {
        matrix.clear();
    }

        if (calibrationCount >= calibrationSamples) {
            pitchOffset = pitchSum / calibrationCount;
            rollOffset = rollSum / calibrationCount;
            calibrationComplete = true;
            matrix.loadFrame(directionS);  // Leave STOP icon illuminated
            Monitor.println("Movement calibration complete");
        }
    } else {
        tiltPitch = rawPitch - pitchOffset;
        tiltRoll = rawRoll - rollOffset;

        Bridge.notify("orientation_update", tiltPitch, tiltRoll);
    }
}
  
// Read distance sensor
if (distance.available()) {
    currentDistanceMm = distance.get();

    Serial.print("Distance: ");
    Serial.print(currentDistanceMm);
    Serial.println(" mm");

    Bridge.notify("distance_update", currentDistanceMm);

    // Check for an obstacle while moving forward autonomously
if (autonomousMode &&
    autoState == AUTO_FORWARD &&
    currentDistanceMm >= 50 &&
    currentDistanceMm < OBSTACLE_DISTANCE) {

    Monitor.println("MCU: OBSTACLE DETECTED");

    autoState = AUTO_REVERSE;
    autoStateStart = millis();
    backward();
}
    }
  }
  // Autonomous driving state machine
if (autonomousMode) {

    unsigned long now = millis();

    // Reverse away from the obstacle
    if (autoState == AUTO_REVERSE &&
        now - autoStateStart >= REVERSE_TIME) {

        autoState = AUTO_TURN;
        autoStateStart = now;

        // Randomly choose left or right
        if (random(0, 2) == 0) {
            left();
        } else {
            right();
        }
    }

    // Finish turning and resume forward movement
    else if (autoState == AUTO_TURN &&
             now - autoStateStart >= TURN_TIME) {

        autoState = AUTO_FORWARD;
        forward();
    }
  }
}