#include <Modulino.h>

ModulinoMovement movement;

float x, y, z;
float pitch, roll;

void setup() {
  Serial.begin(115200);

  Modulino.begin();
  movement.begin();
}

void loop() {

  movement.update();

  x = movement.getX();
  y = movement.getY();
  z = movement.getZ();

  // Calculate tilt
  pitch = atan2(z, sqrt(x*x + y*y)) * 180.0 / PI;
  roll = atan2(x, -y) * 180.0 / PI;

  Serial.print("Pitch: ");
  Serial.print(pitch, 1);

  Serial.print("  Roll: ");
  Serial.println(roll, 1);

  delay(100);
}