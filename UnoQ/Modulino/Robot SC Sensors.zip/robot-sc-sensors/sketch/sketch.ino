#include <ArduinoGraphics.h>
#include <Arduino_LED_Matrix.h>
#include <Servo.h>
#include <Arduino_RouterBridge.h>
#include <Arduino_Modulino.h>
#include "direction.h"

ArduinoLEDMatrix matrix;
ModulinoMovement movement;
ModulinoDistance distance;
ModulinoBuzzer buzzer;

unsigned long lastMovementRead = 0;
float tiltPitch = 0;
float tiltRoll = 0;

Servo servo1;
Servo servo2;

void forward() {
    Monitor.println("MCU: FORWARD");
    matrix.clear();
    matrix.loadFrame(directionF);
    servo1.write(0);
    servo2.write(180);
}

void backward() {
    Monitor.println("MCU: BACKWARD");
    matrix.clear();
    matrix.loadFrame(directionB);
    servo1.write(180);
    servo2.write(0);
}

void left() {
    Monitor.println("MCU: LEFT");
    matrix.clear();
    matrix.loadFrame(directionL);
    servo1.write(0);
    servo2.write(0);
}

void right() {
    Monitor.println("MCU: RIGHT");
    matrix.clear();
    matrix.loadFrame(directionR);
    servo1.write(180);
    servo2.write(180);
}

void stopServos() {
    Monitor.println("MCU: STOP");
    matrix.clear();
    matrix.loadFrame(directionS);
    servo1.write(90);
    servo2.write(90);
}

void buzzerOn() {
    buzzer.tone(1000, 60000);
}

void buzzerOff() {
    buzzer.noTone();
}

void setup() {

    matrix.begin();
    Modulino.begin();
    movement.begin();
    distance.begin();
    buzzer.begin();
   
    servo1.attach(9);
    servo2.attach(10);

    Monitor.begin();
    Bridge.begin();

    Bridge.provide_safe("forward", forward);
    Bridge.provide_safe("backward", backward);
    Bridge.provide_safe("left", left);
    Bridge.provide_safe("right", right);
    Bridge.provide_safe("stop", stopServos);
    Bridge.provide_safe("buzzer_on", buzzerOn);
    Bridge.provide_safe("buzzer_off", buzzerOff);

    stopServos();

    Monitor.println("MCU: Bridge ready");
}

void loop() {

if (millis() - lastMovementRead >= 200) {
  lastMovementRead = millis();

  if (movement.update()) {
    float x = movement.getX();
    float y = movement.getY();
    float z = movement.getZ();

    // Calculate tilt angles from acceleration
    tiltPitch = atan2(z, sqrt(x * x + y * y)) * 180.0 / PI;
    tiltRoll  = atan2(x, -y) * 180.0 / PI;

    Bridge.notify("orientation_update", tiltPitch, tiltRoll);
    
    Serial.print("  | Tilt Pitch: ");
    Serial.print(tiltPitch, 1);

    Serial.print("  Tilt Roll: ");
    Serial.println(tiltRoll, 1);
    }
  
  if (distance.available()) {
    float distanceMm = distance.get();

    Serial.print("Distance: ");
    Serial.print(distanceMm);
    Serial.println(" mm");

    Bridge.notify("distance_update", distanceMm);
}
  }
}