from arduino.app_utils import *
from arduino.app_bricks.web_ui import WebUI


def forward_handler(client, data):
    print("FORWARD")
    Bridge.call("forward")


def backward_handler(client, data):
    print("BACKWARD")
    Bridge.call("backward")


def left_handler(client, data):
    print("LEFT")
    Bridge.call("left")


def right_handler(client, data):
    print("RIGHT")
    Bridge.call("right")


def stop_handler(client, data):
    print("STOP")
    Bridge.call("stop")

def orientation_handler(pitch, roll):
    # print(f"Pitch: {pitch:.1f}  Roll: {roll:.1f}")

    ui.send_message("orientation_update", {
        "pitch": pitch,
        "roll": roll
    })
    
def distance_handler(distance):
    ui.send_message("distance_update", {
        "distance": distance
    })
    
def buzzer_on_handler(client, data):
    print("BUZZER ON")
    Bridge.call("buzzer_on")

def buzzer_off_handler(client, data):
    print("BUZZER OFF")
    Bridge.call("buzzer_off")

def autonomous_on_handler(client, data):
    print("AUTONOMOUS ON")
    Bridge.call("autonomous_on")


def autonomous_off_handler(client, data):
    print("AUTONOMOUS OFF")
    Bridge.call("autonomous_off")


ui = WebUI()

ui.on_message('forward', forward_handler)
ui.on_message('backward', backward_handler)
ui.on_message('left', left_handler)
ui.on_message('right', right_handler)
ui.on_message('stop', stop_handler)
ui.on_message('buzzer_on', buzzer_on_handler)
ui.on_message('buzzer_off', buzzer_off_handler)
ui.on_message('autonomous_on', autonomous_on_handler)
ui.on_message('autonomous_off', autonomous_off_handler)

Bridge.provide("orientation_update", orientation_handler)
Bridge.provide("distance_update", distance_handler)

App.run()