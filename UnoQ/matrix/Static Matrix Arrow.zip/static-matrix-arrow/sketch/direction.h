// Animation: Animation

// direction.h
const uint32_t directionStop[4] = {
    0x0c00c00c,
    0x00ff07f8,
    0x18006001,
    0x80000000
};

const uint32_t animation[][5] = {
    {0x0c00c00c, 0x00ff07f8, 0x18006001, 0x80000000, 1000},  // Frame 1
    {0x01800600, 0x181fe0ff, 0x00300300, 0x30000000, 1000},  // Frame 1 (copy)
    {0x06007807, 0xe06d8264, 0x03001800, 0xc0000000, 1000},  // Frame 1 (copy) (copy)
    {0x06003001, 0x804c836c, 0x0fc03c00, 0xc0000000, 1000},  // Frame 1 (copy) (copy) (copy)
    {0x00003003, 0xc0330198, 0x07801800, 0x00000000, 1000},  // Frame 6
};
